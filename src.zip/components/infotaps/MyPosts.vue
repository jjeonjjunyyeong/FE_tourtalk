<template>
  <div>
    <h3 class="mb-4">내가 작성한 게시글</h3>
    <ul v-if="posts.length">
      <li v-for="post in posts" :key="post.postId">
        <strong>{{ post.title }}</strong> - {{ post.createdAt }}
      </li>
    </ul>
    <p v-else>작성한 게시글이 없습니다.</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
// import postService from '@/services/post' // 추후 사용 예정

const posts = ref([])

onMounted(async () => {
  // const res = await postService.getMyPosts()
  // posts.value = res.data
})
</script>
